#!/bin/bash

if [ -f efface_moi ];then
	rm efface_moi
fi
