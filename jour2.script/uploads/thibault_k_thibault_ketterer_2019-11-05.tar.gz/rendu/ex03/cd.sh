#!/bin/bash
mkdir toto
cd toto
ls
