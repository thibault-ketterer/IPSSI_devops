#!/bin/bash
date
